import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.appi.AuthRepository
import com.example.appi.LoginActivity
import com.example.appi.databinding.ActivitySignupBinding  // Make sure this import exists

class Signup : AppCompatActivity() {
    private lateinit var binding: ActivitySignupBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSignup.setOnClickListener {
            if (validateInput()) {
                val username = binding.etUsername.text.toString()
                val email = binding.etEmail.text.toString()
                val password = binding.etPassword.text.toString()
                val confirmPassword = binding.etConfirmPassword.text.toString()

                if (password != confirmPassword) {
                    binding.etConfirmPassword.error = "Passwords don't match"
                    return@setOnClickListener
                }

                if (AuthRepository.signUp(username, email, password)) {
                    Toast.makeText(this, "Signup successful!", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this, LoginActivity::class.java))
                    finish()
                } else {
                    Toast.makeText(this, "Email already registered", Toast.LENGTH_SHORT).show()
                }
            }
        }

        binding.tvLogin.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))

        }
    }

    private fun validateInput(): Boolean {
        var isValid = true

        if (binding.etUsername.text.isNullOrBlank()) {
            binding.etUsername.error = "Username is required"
            isValid = false
        }

        if (binding.etEmail.text.isNullOrBlank() || !Patterns.EMAIL_ADDRESS.matcher(binding.etEmail.text.toString()).matches()) {
            binding.etEmail.error = "Valid email is required"
            isValid = false
        }

        if (binding.etPassword.text.isNullOrBlank() || binding.etPassword.text.toString().length < 6) {
            binding.etPassword.error = "Password must be at least 6 characters"
            isValid = false
        }

        if (binding.etConfirmPassword.text.isNullOrBlank()) {
            binding.etConfirmPassword.error = "Please confirm password"
            isValid = false
        }

        return isValid
    }
}