package com.example.appi

import Signup
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit
import com.example.appi.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding

    companion object {
        const val PREFS_NAME = "AppPrefs"
        const val CURRENT_USER_ID = "CURRENT_USER_ID"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLogin.setOnClickListener {
            if (validateInput()) {
                val email = binding.etEmail.text.toString()
                val password = binding.etPassword.text.toString()

                val user = AuthRepository.login(email, password)
                if (user != null) {
                    saveUserSession(user.id)
                    navigateToMain()
                } else {
                    showLoginError()
                }
            }
        }

        binding.tvSignup.setOnClickListener {
            navigateToSignup()
        }
    }

    private fun saveUserSession(userId: Int) {
        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit {
            putInt(CURRENT_USER_ID, userId)
            apply()
        }
    }

    private fun navigateToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun showLoginError() {
        Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show()
    }

    private fun navigateToSignup() {
        startActivity(Intent(this, Signup::class.java))

    }

    private fun validateInput(): Boolean {
        var isValid = true

        if (binding.etEmail.text.isNullOrBlank()) {
            binding.etEmail.error = "Email is required"
            isValid = false
        }

        if (binding.etPassword.text.isNullOrBlank()) {
            binding.etPassword.error = "Password is required"
            isValid = false
        }

        return isValid
    }
}