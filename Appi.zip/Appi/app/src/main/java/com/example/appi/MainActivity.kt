package com.example.appi

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.appi.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Check if user is logged in
        val sharedPref = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        val userId = sharedPref.getInt("CURRENT_USER_ID", -1)

        if (userId == -1) {
            // No user logged in, redirect to login
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        // Get current user
        val user = AuthRepository.getUserById(userId)
        user?.let {
            binding.tvWelcome.text = "Welcome, ${it.username}!"
            binding.tvEmail.text = "Email: ${it.email}"
        } ?: run {
            Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        binding.btnLogout.setOnClickListener {
            // Clear user session
            with(sharedPref.edit()) {
                remove("CURRENT_USER_ID")
                apply()
            }
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}