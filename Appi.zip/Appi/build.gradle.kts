// Top-level build file
plugins {
    id("com.android.application") version "8.2.2" apply false  // Changed from 8.6.0
    id("com.android.library") version "8.2.2" apply false     // Changed from 8.6.0
    id("org.jetbrains.kotlin.android") version "1.9.10" apply false  // Compatible version
}



// This should be in settings.gradle.kts instead:
dependencies {
    repositories {
        google()
        mavenCentral()
    }
}