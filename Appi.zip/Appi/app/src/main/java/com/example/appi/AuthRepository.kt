package com.example.appi

object AuthRepository {
    private val users = mutableListOf<User>()
    private var nextId = 1

    fun signUp(username: String, email: String, password: String): Boolean {
        // Check if user already exists
        if (users.any { it.email == email }) {
            return false
        }

        val newUser = User(
            id = nextId++,
            username = username,
            email = email,
            password = password // In real app, hash this password
        )
        users.add(newUser)
        return true
    }

    fun login(email: String, password: String): User? {
        return users.find { it.email == email && it.password == password }
    }

    fun getUserById(id: Int): User? {
        return users.find { it.id == id }
    }
}